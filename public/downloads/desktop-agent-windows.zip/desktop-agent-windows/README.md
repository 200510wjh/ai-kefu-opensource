# Windows AI Customer Service Agent

This package is for MVP customer testing.

## Requirements

- Windows 10/11
- Python 3.11+
- Tesseract OCR, only needed when OCR mode is used
- A valid merchant backend login token

## Start

1. Edit scripts/desktop_listener.config.example.json.
2. Put your backend token into auth_token, or set MERCHANT_DESKTOP_AUTH_TOKEN.
3. Run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\run-windows.ps1
```

Default mode is auto_paste. Guarded auto-send requires mode=auto_send, send=true, and confirm_send=CONFIRM_DESKTOP_AUTO_SEND.
